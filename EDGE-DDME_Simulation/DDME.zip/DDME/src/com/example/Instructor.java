package com.example;

import java.io.IOException;

public class Instructor {
    private String query;
    private Frame frame;
    private CommunicationUnit cu;
    private Processor pe;


    public Instructor(String query, Frame frame,CommunicationUnit cu,Processor PE) {
        this.query = query;
        this.frame = frame;
        this.cu  = cu;
        pe = PE;
    }
    public void startQueryInArchiveTrack(){
        pe.processArchive(query,frame);
    }
    public void startQueryInLiveTrack(){
        try{
            String score = pe.scoreQuery(frame);
            System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Sending Live track Query to edge");
            cu.sendQuery(score,pe.getEdge());
            cu.queryDone();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    //getters and setters
    public String getQuery() { return query; }

    public void setQuery(String query) { this.query = query; }

    public Frame getFrame() { return frame; }

    public void setFrame(Frame frame) { this.frame = frame; }


}
