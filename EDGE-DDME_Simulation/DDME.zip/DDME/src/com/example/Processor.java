package com.example;

import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

public class Processor {
    private Edge edge;  //Edges (only one edge for now) to which the DDME is connected
    private ArchiveStorage store;
    private List<String> coordinates;
    private Map<Frame,Integer> archiveScoreMap;

    public Processor(){
        coordinates = new ArrayList<String>();
        archiveScoreMap = new HashMap< Frame,Integer>();
    }
    public Processor(Edge edge, ArchiveStorage store) {
        this.edge = edge;
        this.store = store;
        coordinates = new ArrayList<String>();
        archiveScoreMap = new HashMap<Frame,Integer>();
    }

    public void processArchive(String query, Frame frame){

        //searching in Archive Storage
        System.out.println(Color.YELLOW+Thread.currentThread().getName()+ " : Fetching list for QP in Archive Track");
        ArrayList<Frame> list = store.fetchFrames(edge);
        if(list.size()>=10){
            //run algorithm on all these frames and compare with HOG of query
            Iterator itr = list.iterator();
            Map<Frame,Double> scores = new HashMap<Frame, Double>();
            int count = 0;
            while (itr.hasNext())
            {
                Frame f = (Frame) itr.next();
                double score = findScore(f,frame);
                scores.put(f,score);
                count+=1;
                archiveScoreMap.put(f,count);
            }
            try{
                sendToScreen(scores);
            }catch(IOException e){
                e.printStackTrace();
            }
        }else{
            System.out.println(Color.YELLOW+Thread.currentThread().getName()+" : List size is not enough to process");
        }
    }

    public void processLive(Map<Double,Double> details,Map<Double,String> XYmap,LiveStorage liveStorage,JPanel panel){
        //receiver of DDME will call this function on receiving the query result from edge
        //fetch the frame from Live storage based on Details and display on screen
        //as Edge receives query, it sends ack to AS and then As stops storing frames and Live storage will be active
        //Edge starts sending frames and initiate a local  counter
        //LS will also starts counter at the same time
        //Edge will send the query result as details (counter of frames having top scores)
        //those counters will then be used here in this function to fetch frames from LS to display on screen

        //details  : counter:score
        Map<Double,Double> map = sortMap(details);
        Iterator<Map.Entry<Double, Double>> itr = map.entrySet().iterator();
        int count = 0;

        System.out.println(Thread.currentThread().getName()+" : Live Storage count "+liveStorage.getStoreCount());
        while (itr.hasNext()) {
            count+=1;
            Map.Entry<Double, Double> entry = itr.next();

            double temp = Math.round(entry.getKey());
            String name =  liveStorage.getPath()+"f_"+(int) temp+".jpg";
            String[] coord = XYmap.get(temp).split(",");

            int x = Integer.parseInt(coord[0]);
            int y = Integer.parseInt(coord[1]);
            System.out.println(Color.CYAN+Thread.currentThread().getName()+" Processing FrameID : "+temp);
            System.out.println(Color.CYAN+Thread.currentThread().getName()+" Processing FrameName : "+name);
            Mat imageMatrix = Imgcodecs.imread(name);
            // Drawing a Rectangle
            Imgproc.rectangle (
                    imageMatrix,                    //Matrix obj of the image
                    new Point(x, y),        //p1
                    new Point(50, 50),       //p2
                    new Scalar(0, 0, 255),     //Scalar object for color
                    5                          //Thickness of the line
            );

            try{
                MatOfByte matOfByte = new MatOfByte();
                Imgcodecs.imencode(".jpg", imageMatrix, matOfByte);
                byte[] byteArray = matOfByte.toArray();
                InputStream in = new ByteArrayInputStream(byteArray);
                BufferedImage bufImage = ImageIO.read(in);
                panel.add (new JLabel (new ImageIcon (bufImage)));
            }catch(IOException e){
                e.printStackTrace();
            }
        }
        JFrame  frame  = new JFrame ("Live Frames");
        frame.getContentPane().add (panel);
        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private double findScore(Frame test, Frame target){
        //calculate HOG of the target
        String s = scoreQuery(target);
        //now comparing the test and the target
        String output = HOG.compare(test.getData(),s);
        String [] out = output.split(",");
        //paste the HOG and comparison function
        String coord = out[1]+","+out[2];
        coordinates.add(coord);
        //populate the coordinates list with x,y as string
        return Double.parseDouble(out[0]);
    }

    public String scoreQuery(Frame query){
        //calculate the hog here
        Size cell = query.getData().size();
        int [] cellSize = new int[]{(int) cell.height, (int) cell.width};    //give the size of the image here
        HOG.hogDescriptor(query.getData(),cellSize);
        Double[] hog = HOG.buckets_vals;
        StringBuilder s = new StringBuilder();
        for (int i=0;i<hog.length;i++){
            s.append(hog[i]);
            if(i!=hog.length-1){
                s.append(",");
            }
        }
        return s.toString();
    }
    private void sendToScreen(Map<Frame,Double> scores) throws IOException {
        //find the top 10 scores and display on screen of archive storage
        Map<Frame,Double> map = sortMapD(scores);
        Iterator<Map.Entry<Frame, Double>> itr = map.entrySet().iterator();

        JPanel  panel  = new JPanel ();
        int i=0;
        while (itr.hasNext()) {
            Map.Entry<Frame, Double> entry = itr.next();
            int index = archiveScoreMap.get(entry.getKey());    //find the index of that frames to map with coordinates

            Mat imageMatrix = entry.getKey().getData();
            String[] coord = coordinates.get(index).split(",");
            int x = Integer.parseInt(coord[0]);
            int y = Integer.parseInt(coord[1]);
            // Drawing a Rectangle
            Imgproc.rectangle (
                    imageMatrix,                    //Matrix obj of the image
                    new Point(x, y),        //p1
                    new Point(50, 50),       //p2
                    new Scalar(0, 0, 255),     //Scalar object for color
                    5                          //Thickness of the line
            );
            MatOfByte matOfByte = new MatOfByte();
            Imgcodecs.imencode(".jpg", imageMatrix, matOfByte);
            byte[] byteArray = matOfByte.toArray();
            InputStream in = new ByteArrayInputStream(byteArray);
            BufferedImage bufImage = ImageIO.read(in);
            panel.add (new JLabel (new ImageIcon (bufImage)));
        }
        JFrame  frame  = new JFrame ("Archive Frames");
        frame.getContentPane().add (panel);
        frame.pack();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    //getters and setters
    public Edge getEdge() { return edge; }

    public void setEdge(Edge edge) { this.edge = edge; }

    public ArchiveStorage getStore() { return store;}

    public void setStore(ArchiveStorage store) { this.store = store; }
//utilities

    public static Map<Double, Double> sortMap(Map<Double, Double> map) {
        List<Map.Entry<Double, Double>> capitalList = new LinkedList<Map.Entry<Double, Double>>(map.entrySet());

        Collections.sort(capitalList, new Comparator<Map.Entry<Double, Double>>() {
            @Override
            public int compare(Map.Entry<Double, Double> o1, Map.Entry<Double, Double> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }
        });

        LinkedHashMap<Double, Double> result = new LinkedHashMap<Double, Double>();
        for (Map.Entry<Double, Double> entry : capitalList)
        {
            result.put(entry.getKey(), entry.getValue());
        }

        return result;
    }
    public static Map<Frame, Double> sortMapD(Map<Frame, Double> map) {
        List<Map.Entry<Frame, Double>> capitalList = new LinkedList<Map.Entry<Frame, Double>>(map.entrySet());

        Collections.sort(capitalList, new Comparator<Map.Entry<Frame, Double>>() {
            @Override
            public int compare(Map.Entry<Frame, Double> o1, Map.Entry<Frame, Double> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }
        });

        LinkedHashMap<Frame, Double> result = new LinkedHashMap<Frame, Double>();
        for (Map.Entry<Frame, Double> entry : capitalList)
        {
            result.put(entry.getKey(), entry.getValue());
        }

        return result;
    }
}