package com.example;

import java.util.ArrayList;

public class Edge {
    private String IP;      //IP address
    private int cameraCap;  //number of cameras tht can be associated to this edge (for now -> 1)
    public ArrayList<Camera> cameraList;    //lit of cameras associated

    public  Edge(){

    }
    public Edge(String IP, int cameraCap) {
        this.IP = IP;
        this.cameraCap = cameraCap;
        cameraList = new ArrayList<Camera>();
    }
    public boolean addCamera(Camera cam){
        if (cameraList.size()>=this.cameraCap){
            return false;
        }
        cameraList.add(cam);
        return true;
    }
    /***************************************************************************************************************/
    //getters and setters
    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        System.out.println("Setting the IP of Edge");
       try{
           this.IP = IP;
       }catch(NullPointerException e){
           e.printStackTrace();
       }
    }

    public int getCameraCap() {
        return cameraCap;
    }

    public void setCameraCap(int cameraCap) {
        this.cameraCap = cameraCap;
    }

    public ArrayList<Camera> getCameraList() {
        return cameraList;
    }

    public void setCameraList(ArrayList<Camera> cameraList) {
        this.cameraList = cameraList;
    }
}
