package com.example;

import org.opencv.core.Mat;

public class Frame {
    private Mat data;   //store the image

    public Edge edge;
    public Camera cam;


    public Frame(Mat data){
        this.data=data;
    }
    public Frame(Mat data, Edge edge, Camera cam) {
        this.data = data;
        this.edge = edge;
        this.cam = cam;
    }

    //getters and setters
    public Mat getData() { return data; }

    public void setData(Mat data) { this.data = data; }


    public Edge getEdge() { return edge; }

    public void setEdge(Edge edge) { this.edge = edge; }

    public Camera getCam() { return cam; }

    public void setCam(Camera cam) { this.cam = cam; }
}
