package com.example;
//@author Yash Kudesia

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {

    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        System.out.println("Initializing the Software ... ");
        clean("C:\\Users\\yashk\\Desktop\\PROJECT\\NextTrack\\MVP");
        clean("C:\\Users\\yashk\\Desktop\\PROJECT\\NextTrack\\LiveS");

        //thread communication init
        AtomicBoolean init = new AtomicBoolean(false);
        AtomicBoolean live_init = new AtomicBoolean(false);
        AtomicBoolean archivestore_cap = new AtomicBoolean(false);
        AtomicInteger gap = new AtomicInteger(0);


        //initializing the variables
        ArchiveStorage archiveStorage = new ArchiveStorage();
        archiveStorage.setPath("C:\\Users\\yashk\\Desktop\\PROJECT\\NextTrack\\MVP\\");

        final Processor processor = new Processor();
        processor.setStore(archiveStorage);



        final CommunicationUnit communicationUnit  = new CommunicationUnit("127.0.0.1",5000,5001,archivestore_cap,init, live_init,gap);
        communicationUnit.setArchiveStorage(archiveStorage);
        communicationUnit.setProcessor(processor);

        //pass the test query in form of image
        Imgcodecs imageCodecs = new Imgcodecs();
        Mat matrix = imageCodecs.imread("C:\\Users\\yashk\\Desktop\\PROJECT\\Capture.JPG");
        Imgproc.resize(matrix, matrix, new Size(64, 128));
        Frame userQ = new Frame(matrix);
        final Instructor instructor = new Instructor("white car",userQ,communicationUnit,processor);



        //this thread will make a connection and fetch data
        new Thread(){
            @Override
            public void run(){
                 boolean t = communicationUnit.connectToedge();
                 System.out.println(Color.BLUE+Thread.currentThread().getName()+"  Closed");
            }
        }.start();

        //this thread will listen whether the meta info is received or not on above thread
        Thread meta_info = new Thread(){
            @Override
            public void run(){
                boolean notSet = true;
                try{
                    System.out.println(Color.GREEN+Thread.currentThread().getName()+" : Processor initialization waiting for meta information from edge");
                    while(notSet){
                        notSet = false;
                        if (communicationUnit.init_flag.get()){
                            Edge  edge = communicationUnit.edge;
                            processor.setEdge(edge);
                            notSet = false;
                            System.out.println(Color.GREEN+Thread.currentThread().getName() + " : Received the meta information succesfully");
                        }else{
                            notSet = true;
                        }
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
                System.out.println(Color.GREEN+Thread.currentThread().getName()+"  Closed");
            }
        };
        meta_info.start();

        //now the variables are initialized and the frames are being fetched in background by CU

        //moving to query processing
        //this thread will use to setup communication with the edge for the query results

        //this thread will process query on Archive memory
        new Thread(){
            @Override
            public void run() {
                System.out.println(Color.YELLOW+Thread.currentThread().getName()+" : Started query processing in Archive track");
                while (true){
                    if(communicationUnit.archivestore_cap.get()){
                        //means we have more than 10 frames
                        instructor.startQueryInArchiveTrack();
                        break;
                    }
                }
                System.out.println(Color.YELLOW+Thread.currentThread().getName()+"  Closed");
            }
        }.start();

        new Thread(){
            @Override
            public void run() {
                System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Waiting to start query processing in Live track");
                while (true){
                    if(communicationUnit.archivestore_cap.get()){
                        //means we have more than 10 frames
                        System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Live Track QP initializing ...");
                        instructor.startQueryInLiveTrack();
                        break;
                    }
                }
                System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Finished query processing in Live track");
            }
        }.start();
        System.out.println(Thread.currentThread().getName()+" is running");
        System.out.println(Thread.currentThread().getState());

    }

    public static void clean(String directoryName){
        File directory = new File(directoryName);
        File[] files = directory.listFiles();
        for (File file : files)
        {
            if (!file.delete()) { System.out.println("Failed to delete "+file); }
        }
    }
}

