package com.example;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ArchiveStorage {
    private ConcurrentHashMap<Frame, Integer> framesMap;     //stores the frames and a integer index for mapping
    private ConcurrentHashMap<Integer, Edge> edgeMap;     //map the integer to find the edge
    private ConcurrentHashMap<Integer, Camera> cameraMap;  // and camera for that frame
    private String path;
    volatile private int storeCount;

    public ArchiveStorage() {
        framesMap = new ConcurrentHashMap<Frame, Integer>();
        edgeMap = new ConcurrentHashMap<Integer, Edge>();
        cameraMap = new ConcurrentHashMap<Integer, Camera>();
        storeCount  = 0;
    }

    public void save(Frame frame,int count){
        //Actual : save to server storage
        //Simulation : save the frames to a local storage specified by the path
        //return the ID of server storage
        Imgcodecs imageCodecs = new Imgcodecs();
        String name = path + "//f_" +Integer.toString(count)+".jpg";
        imageCodecs.imwrite(name, frame.getData());

    }
    public void addFrames(Frame frame,int counter){
        save(frame,counter);
        int ID = counter;
        storeCount = storeCount+1;
        Mat m = new Mat();
        Frame f = new Frame(m,frame.edge,frame.cam);
        framesMap.put(f,ID);
        edgeMap.put(ID,f.edge);
        cameraMap.put(ID,f.cam);
    }

    public ArrayList<Frame> fetchFrames(Edge edg) {

        ArrayList<Frame> list = new ArrayList<Frame>();
        int count = 10; //give only 10 frames
        if (edgeMap.containsValue(edg)) {
            Iterator<Map.Entry<Integer, Edge>> itr = edgeMap.entrySet().iterator();
            while (itr.hasNext()  && count-->0) {
                Map.Entry<Integer, Edge> entry = itr.next();
                if (entry.getValue().equals(edg)) {
                    //fetch the frame at location id entry.getKey() and put in the list
                    Imgcodecs imageCodecs = new Imgcodecs();
                    String name =path+"f_"+Integer.toString(entry.getKey())+".jpg";
                    Mat matrix = imageCodecs.imread(name);
                    Frame f = new  Frame(matrix,entry.getValue(),cameraMap.get(entry.getKey()));
                    list.add(f);
                }

            }
        }
        return list;
    }

    public Frame getFrame(int ID){
        Edge edge = edgeMap.get(ID);
        Camera cam = cameraMap.get(ID);
        Imgcodecs imageCodecs = new Imgcodecs();
        String name =path+"f_"+Integer.toString(ID)+".jpg";
        Mat matrix = imageCodecs.imread(name);
        Frame f = new Frame(matrix,edge,cam);
        return f;
    }
    /**************************************************************************************************************************************/
    //getters and setters

    public void setPath(String path) { this.path = path; }
    public String getPath() { return path; }

    public int getStoreCount() {
        return storeCount;
    }

    public Map<Frame, Integer> getFramesMap() { return framesMap; }

    public Map<Integer, Edge> getEdgeMap() { return edgeMap; }

    public Map<Integer, Camera> getCameraMap() { return cameraMap; }
}