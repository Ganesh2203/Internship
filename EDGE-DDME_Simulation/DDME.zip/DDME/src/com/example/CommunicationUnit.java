package com.example;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;

import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class CommunicationUnit {
    private String DDME_IP;
    private int DDME_PORT;
    private int DDME_QP_PORT;

    private String Edge_IP;
    private int Edge_PORT;

    public Edge edge;   //for meta information
    public AtomicBoolean  init_flag;       //flag is true when the meta information is received from the edge
    public ArchiveStorage archiveStorage;
    private LiveStorage liveStorage;
    public AtomicBoolean liveStorage_init;  //flag is true when LS needed to be started
    public Processor processor;
    public AtomicBoolean archivestore_cap;
    public AtomicInteger gap;

    public CommunicationUnit(String DDME_IP, int DDME_PORT,int DDME_QP_PORT,AtomicBoolean as_cap,AtomicBoolean init, AtomicBoolean live_init,AtomicInteger Gap) {
        this.DDME_IP = DDME_IP;
        this.DDME_PORT = DDME_PORT;
        this.DDME_QP_PORT = DDME_QP_PORT;
        edge = new Edge();
        init_flag = init;
        archivestore_cap =as_cap;
        liveStorage_init = live_init;
        gap = Gap;
    }


    //sender------------------------------------------------------------
    public void sendQuery(String frame_score, Edge edge) throws IOException {
        Socket socket            = null;
        DataInputStream  input   = null;
        DataOutputStream out     = null;

        //making connection
        try
        {
            socket = new Socket(DDME_IP, DDME_QP_PORT);
            System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Connected to edge for QP in Live Track");
            input  = new DataInputStream(socket.getInputStream());
            // sends output to the socket
            out    = new DataOutputStream(socket.getOutputStream());
        }
        catch(UnknownHostException u) { u.printStackTrace(); }
        catch(IOException i) { i.printStackTrace();}

        //sending the query and wait for acknowledgement
        String line = "";
        out.writeUTF(String.valueOf(frame_score));
        final Map<Double,Double> map = new HashMap<Double,Double>();
        final Map<Double,String> XYmap = new HashMap<Double,String>();
        System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : query sent");
        boolean gap_stored = false;
        final JPanel panel = new JPanel();
        while (!line.equals("Over"))
        {
            System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : query data receiving");
            try {
                assert input != null;
                line =input.readUTF();
                if(line.equals("ACK")){
                    liveStorage_init.set(true);
                    liveStorage = new LiveStorage();
                    System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : query ack received, started fetching score");
                }else{
                    //receive the scores
                    String[] arrOfStr = line.split(",");
                    //counter and score
                    map.put(Double.valueOf(arrOfStr[3]),Double.valueOf(arrOfStr[0]));
                    //counter and XY
                    XYmap.put(Double.valueOf(arrOfStr[3]),(arrOfStr[1].toString()+","+arrOfStr[2].toString()));
                    System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : "+arrOfStr[0]+","+arrOfStr[1]+","+
                            arrOfStr[2]+","+arrOfStr[3]);
                    if(!gap_stored){
                        gap_stored = true;
                        gap.set(Integer.valueOf(arrOfStr[3]));
                    }

                }
                if(map.size()%5==0 && map.size()>4){
                    System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Processing live frames ... ");
                    panel.removeAll();
                    new Thread(){
                        @Override
                        public void run() {
                            processor.processLive(map,XYmap,liveStorage,panel);
                        }
                    }.start();
                }
            } catch(IOException i) { System.out.println(i); }
        }
        // close the connection
        try {
            input.close();
            out.close();
            socket.close();
            System.out.println(Color.PURPLE+Thread.currentThread().getName()+" closed");}
        catch(IOException i) { System.out.println(i); }
    }


    //receiver-----------------------------------------------------------
    //after making connection with the edge, fetch the details of the edge and return a Edge object to main function
    public boolean connectToedge(){
        try
        {
            ServerSocket server = new ServerSocket(DDME_PORT);
            System.out.println(Color.BLUE+Thread.currentThread().getName() + " : DDME Server started");
            System.out.println(Color.BLUE+Thread.currentThread().getName() + " : Waiting for a Edge client ...");
            Socket socket = server.accept();
            System.out.println(Color.BLUE+Thread.currentThread().getName() + " : Client accepted");
            // takes input from the client socket
            DataInputStream inObj = new DataInputStream(
                    new BufferedInputStream(socket.getInputStream()));
            String line = "";
            // reads message from client until "Over" is sent
            List<String> data = new ArrayList<String>();
            int counter = 0;
            String IP ="";
            String cap = "";
            String cam_details ="";
            String status = "";
            System.out.println(Color.BLUE+Thread.currentThread().getName() + " : Preparing to receive data ... ");
            while (!line.equals("Over") && !status.equals("Over"))
            {
                try {
                    if(!init_flag.get()){
                        IP = inObj.readUTF();
                        cap = inObj.readUTF();
                        cam_details = inObj.readUTF();
                        line = inObj.readUTF();
                        if (line.equals("meta")){
                            //means meta information received fully
                            init_flag.set(true);

                            int cap_i = Integer.parseInt(cap);
                            edge.setIP(IP);
                            edge.setCameraCap(cap_i);
                            ArrayList<Camera> cam = new ArrayList<Camera>();
    //                        for(int i = 2;i<data.size();i++){
    //                            String[] arrOfStr = data.get(i).split(", ", 2);
    //                            Camera camera = new Camera(Integer.parseInt(arrOfStr[1]),edge,arrOfStr[0]);
    //                            cam.add(camera);
    //                        }
                            String[] arrOfStr = cam_details.split(",");
                            //System.out.println(arrOfStr);
                            Camera camera = new Camera(Integer.parseInt(arrOfStr[1]),edge,arrOfStr[0]);
                            cam.add(camera);
                            edge.setCameraList(cam);
                            data = new ArrayList<String>();
                        }
                    }

                    else{
                        status = inObj.readUTF();
                        if(status.equals("Over")){
                            break;
                        }
                        //now frames will be received
                        int length = inObj.readInt();
                        //System.out.println("Length : "+length);

                        byte[] bytes = new byte[length];
                        int Bytes = inObj.read(bytes);
                        //converting byte to mat
                        Mat m = convertBytestoMAT(bytes);

                        String IP_camera = inObj.readUTF();
                        int fps_camera = inObj.readInt();
                        int frame_count  = inObj.readInt();


                        //received a complete frame
                        Camera cam = new Camera(fps_camera,edge,IP_camera);
                        Frame f = new Frame(m,edge,cam);
                        if(!liveStorage_init.get()){
                            archiveStorage.addFrames(f,frame_count);
                            counter = counter+1;
                            if(counter>10){
                                archivestore_cap.set(true);
                            }
                        }else {
                            liveStorage.addFrames(f,frame_count);
                            if(gap.get()>0){
                                fillGap(frame_count);
                                gap.set(0);
                            }
                        }
                    }
                    //System.out.println(line);
                } catch(IOException i) { i.printStackTrace();}
            }
            System.out.println(Color.BLUE+Thread.currentThread().getName() + " : Closing connection");
            // close connection
            socket.close();
//            in.close();
            inObj.close();
        }
        catch(IOException i)
        {
            System.out.println(i);
        }
        return true;
    }

    private void fillGap(int endframeID){
        System.out.println(Color.BLUE+Thread.currentThread().getName()+" Gap : "+(endframeID - gap.get()));
        int startframeID = gap.get();
        for(int i=startframeID;i<endframeID;i++) {
            Frame f = archiveStorage.getFrame(i);
            liveStorage.save(f,i);
        }
    }
    public void queryDone(){
        liveStorage.saveToArchive(archiveStorage);
    }

    private Mat convertBytestoMAT(byte [] s){
        Mat mat = Imgcodecs.imdecode(new MatOfByte(s), Imgcodecs.CV_LOAD_IMAGE_UNCHANGED);
        return mat;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void setArchiveStorage(ArchiveStorage archiveStorage) {
        this.archiveStorage = archiveStorage;
    }

    public void setProcessor(Processor processor) {
        this.processor = processor;
    }

    public void setLiveStorage(LiveStorage liveStorage) {
        this.liveStorage = liveStorage;
    }
}

