package com.example;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

//this call will be used only when there is a query received
//as and when query is entered, the frames from edges will not be stored in archive and will be buffered here
//Processing or live track will be executed from this storage and then after query is finished, live storage will be
//trashed out and frames will be sent to archive storage for permanent storage
public class LiveStorage {
    private Map<Frame, Integer> framesMap;     //stores the frames and a integer index for mapping
    private Map<Integer, Edge> edgeMap;     //map the integer to find the edge
    private Map<Integer, Camera> cameraMap;  // and camera for that frame
    private String path;
    private int storeCount;

    public LiveStorage() {
        framesMap = new HashMap<Frame, Integer>();
        edgeMap = new HashMap<Integer, Edge>();
        cameraMap = new HashMap<Integer, Camera>();
        storeCount  = 0;
        path = "C:\\Users\\yashk\\Desktop\\PROJECT\\NextTrack\\LiveS\\";
    }

    public void save(Frame frame,int count){
        //Actual : save to server storage
        //Simulation : save the frames to a local storage specified by the path
        //return the ID of server storage
        Imgcodecs imageCodecs = new Imgcodecs();
        String name = path + "//f_" +Integer.toString(count)+".jpg";
        imageCodecs.imwrite(name, frame.getData());

    }
    public void addFrames(Frame frame,int count){
        save(frame,count);
        int ID =count;
        storeCount = storeCount+1;
        Mat m = new Mat();
        Frame f = new Frame(m,frame.edge,frame.cam);
        framesMap.put(f,ID);
        edgeMap.put(ID,f.edge);
        cameraMap.put(ID,f.cam);
    }

    public Frame fetchFrames(int counter) {
        Imgcodecs imageCodecs = new Imgcodecs();
        String name =path+"f_"+counter+".jpg";
        Mat matrix = imageCodecs.imread(name);
        Frame f = new  Frame(matrix,edgeMap.get(counter),cameraMap.get(counter));
        return f;
    }

    public void saveToArchive(ArchiveStorage archiveStorage){
        int Acount = archiveStorage.getStoreCount();
        int Lcount = storeCount;
        int  i =0;
        while(i<Lcount){
            Frame f = fetchFrames(Acount+i);
            archiveStorage.save(f,Acount+i);
            i++;
        }
    }
    /**************************************************************************************************************************************/
    //getters and setters

    public void setPath(String path) { this.path = path; }
    public String getPath() { return path; }

    public Map<Frame, Integer> getFramesMap() { return framesMap; }

    public Map<Integer, Edge> getEdgeMap() { return edgeMap; }

    public Map<Integer, Camera> getCameraMap() { return cameraMap; }

    public int getStoreCount() {
        return storeCount;
    }
}