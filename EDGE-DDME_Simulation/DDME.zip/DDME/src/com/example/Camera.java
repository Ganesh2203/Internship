package com.example;

public class Camera {
    private int fps;
    private Edge assocEdge;
    private String IP;

    public Camera(int fps, Edge assocEdge,String IP) {
        this.fps = fps;
        this.IP = IP;
        this.assocEdge = assocEdge;
    }

    /*****************************************************************************************************************/
    //getters and setters

    public int getFps() {
        return fps;
    }

    public void setFps(int fps) {
        this.fps = fps;
    }

    public Edge getAssocEdge() {
        return assocEdge;
    }

    public void setAssocEdge(Edge assocEdge) {
        this.assocEdge = assocEdge;
    }

}
