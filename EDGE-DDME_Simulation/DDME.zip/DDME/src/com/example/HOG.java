package com.example;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HOG {
    static{ System.loadLibrary(Core.NATIVE_LIBRARY_NAME); }
    //utility functions for HOG
    public static int N_BUCKETS = 9;
    public static int BLOCK_SIZE = 9;
    public static Double[] buckets_vals = new Double[N_BUCKETS];

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void assign_bucket_vals(double m, double d){
        int left_bin = (int) (d /20.);
        //print("d->>>",d,"  ->>left bin : ",left_bin,"  ->> int(d/20) : ",int(d/20))
        int right_bin = ((int)(d / 20.) + 1) % N_BUCKETS;
        if(0 <= left_bin && left_bin < right_bin && right_bin < N_BUCKETS){
            int left_val= (int) (m * (right_bin * 20 - d) / 20);
            int right_val = (int) (m * (d - left_bin * 20) / 20);
            buckets_vals[left_bin] += left_val;
            buckets_vals[right_bin] += right_val;
        }else{
            System.out.println("Errors on the bucket conditions");
            System.exit(-1);
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void get_magnitude_hist_cell(float loc_x, float loc_y, Mat GX, Mat GY, int[] CELL_SIZE ){
        double [][] cell_x = new double[CELL_SIZE[0]][CELL_SIZE[1]];
        double [][] cell_y = new double[CELL_SIZE[0]][CELL_SIZE[1]];


        //now populate these arrays
       // System.out.println(GX.get(124,5));
       // System.out.println(Color.BLACK+Thread.currentThread().getName()+" : "+GX.size()+","+GY.size()+"-----"+CELL_SIZE[0]+","+CELL_SIZE[1]);
        for(int i=0;i<CELL_SIZE[0]-1;i++){
            for(int j=0;j<CELL_SIZE[1]-1;j++){
                //System.out.println(Color.RED+Thread.currentThread().getName()+" : "+(loc_x+i)+" "+(loc_y+j)+" - G_X->"+ Arrays.toString(GX.get((int) loc_x + i, (int) loc_y + j))+" G_y->"+ Arrays.toString(GY.get((int) loc_x + i, (int) loc_y + j)));
                cell_x[i][j]=GX.get((int)loc_x+i,(int)loc_y+j)[0];  //0 for gray channel
                cell_y[i][j]=GY.get((int)loc_x+i,(int)loc_y+j)[0];
            }
        }
        buckets_vals = new Double[N_BUCKETS];
        //initializing the bucket_vals array
        for(int i=0;i<N_BUCKETS;i++){
            buckets_vals[i]= (double) 0;
        }
        //now calculating the magnitudes and directions and the bucket values
        double [][] magnitudes = new double[CELL_SIZE[0]][CELL_SIZE[1]];
        double [][] directions = new double[CELL_SIZE[0]][CELL_SIZE[1]];

        for(int i=0;i<CELL_SIZE[0];i++){
            for(int j=0;j<CELL_SIZE[1];j++){
                magnitudes[i][j]=Math.sqrt((cell_x[i][j] * cell_x[i][j]) +(cell_y[i][j] * cell_y[i][j]));
                directions[i][j] = Math.atan(cell_y[i][j]/cell_x[i][j])* 180 / Math.PI;
                assign_bucket_vals(magnitudes[i][j],directions[i][j]);
            }
        }

    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public static void get_magnitude_hist_block(float loc_x, float loc_y, Mat GX, Mat GY, int[] CELL_SIZE ){
        //now finding the bucket values for the square where start at loc_x and loc_y
        int[] buckets_vals_final = new int[N_BUCKETS*4];
        get_magnitude_hist_cell(loc_x,loc_y,GX,GY,CELL_SIZE);
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //main driver for HOG
    public static void hogDescriptor(Mat args, int[] CELL_SIZE ) {
        // First we declare the variables we are going to use
        Mat src, src_gray = new Mat();
        int scale = 1;
        int delta = 0;
        int ddepth = -1;    //means depth will be same as input

        src = args;
        Imgproc.GaussianBlur( src, src, new Size(3, 3), 0, 0, Core.BORDER_DEFAULT );
        Imgproc.cvtColor( src, src_gray, Imgproc.COLOR_RGB2GRAY );
        Mat grad_x = new Mat(), grad_y = new Mat();
        Imgproc.Sobel( src_gray, grad_x, ddepth, 1, 0, 3, scale, delta, Core.BORDER_DEFAULT );
        Imgproc.Sobel( src_gray, grad_y, ddepth, 0, 1, 3, scale, delta, Core.BORDER_DEFAULT );

        //System.out.println("Sobel kernel applied");
        get_magnitude_hist_block(0,0,grad_x,grad_y,CELL_SIZE);

    }

    public static void hogDescriptorUtil(Mat args,int loc_x,int loc_y,int[] CELL_SIZE ) {
        // First we declare the variables we are going to use
        Mat src, src_gray = new Mat();
        int scale = 1;
        int delta = 0;
        int ddepth = -1;    //means depth will be same as input

        src = args;
        Imgproc.GaussianBlur( src, src, new Size(3, 3), 0, 0, Core.BORDER_DEFAULT );
        Imgproc.cvtColor( src, src_gray, Imgproc.COLOR_RGB2GRAY );
        Mat grad_x = new Mat(), grad_y = new Mat();
        Imgproc.Sobel( src_gray, grad_x, ddepth, 1, 0, 3, scale, delta, Core.BORDER_DEFAULT );
        Imgproc.Sobel( src_gray, grad_y, ddepth, 0, 1, 3, scale, delta, Core.BORDER_DEFAULT );

        //System.out.println("Sobel kernel applied");
        get_magnitude_hist_block(loc_x,loc_y,grad_x,grad_y, CELL_SIZE );

    }
    private static List<Double> convertTOList(String hogS){
        String[] hog = hogS.split(",");
        List<Double> HOG = new ArrayList<Double>();
        for (String s : hog) {
            HOG.add(Double.valueOf(s));
        }
        return  HOG;
    }

    public static double distance(Double[] a, List<Double> b) {
        assert a.length == b.size();
        double squaredDistance = 0.0;
        for(int i=0; i<a.length; i++){
            squaredDistance += Math.pow(a[i] - b.get(i), 2.0);
        }
        return Math.sqrt(squaredDistance);
    }

    private static double findScore(List<Double> targetHOG) {
        return distance(buckets_vals,targetHOG);
    }

    private static String convolveHOG(Mat query, List<Double> targetHOG, int[] CELL_SIZE ) {
        double score = Double.MAX_VALUE;
        int X = -1,Y = -1;
        int w = 64,h=128;
        int x=0,y=0;
        while (y< h - CELL_SIZE[1]){
            x = 0;
            while (x<w-CELL_SIZE[0]){
                hogDescriptorUtil(query,y,x,CELL_SIZE);
                double tempscore = findScore(targetHOG);
                if(tempscore!=-1){
                    if(score>tempscore){
                        score = tempscore;
                        X = x;
                        Y = y;
                    }
                }
                x+=CELL_SIZE[0];
            }
            y+=(int)(CELL_SIZE[1]/2);
        }
        return ""+score+","+X+","+Y;

    }


    public static String compare(Mat query,String target){
        List<Double> targetHOG = convertTOList(target);
        int[] CELL_SIZE = new int []{30,60};
        String s = convolveHOG(query,targetHOG,CELL_SIZE);
        return s;
    }
}
