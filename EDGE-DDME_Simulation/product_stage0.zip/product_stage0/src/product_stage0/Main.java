package product_stage0;

import org.opencv.core.Core;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicBoolean;

public class Main {
    public static void main(String[] args) {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

    /*==============================================================================================================
                                            INITIALIZING the software
    ==============================================================================================================*/
        //path to buffer storage
        String path = "C:\\Users\\yashk\\Desktop\\PROJECT\\NextTrack\\BufferStorage";
        String inputpathvideo =  "C:\\Users\\yashk\\Desktop\\PROJECT\\NextTrack\\highway.mp4";
        String bufferPath =  "C:\\Users\\yashk\\Desktop\\PROJECT\\NextTrack\\BufferStorage";
        AtomicBoolean Bufferclone =  new AtomicBoolean(false);
        AtomicBoolean canFetch =  new AtomicBoolean(false);

        // creates a file object with specified path
        clean(bufferPath);
        File file = new File(path);
        boolean value = file.mkdir();

        BufferStorage bufferStorage = new BufferStorage(bufferPath);
        final Edge edge = new Edge("127.0.0.1", 1,bufferStorage,Bufferclone,canFetch);
        Camera c = new Camera(30,edge,"0.0.0.1");
        edge.addCamera(c);

        System.out.println("Edge Software Starting ...");

         /*==============================================================================================================
                                            Query processing
        ==============================================================================================================*/

        new Thread(() -> edge.listeningQuery()).start();

    /*==============================================================================================================
                                            frame processing
       ==============================================================================================================*/

        for (int i = 0; i < edge.cameraCap; i++)
        {
            Camera cameraInfo = edge.cameraList.get(i);
            System.out.println(cameraInfo.getFps()+" "+cameraInfo.getIP());
            String cameraIP = cameraInfo.getIP();
            new Thread(){
                public void run(){
                    int port = 5000;
                    Socket socket;
                    System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Frame sending Channel Initialized ...");
                    try {
                        socket = new Socket("127.0.0.1", port);
                        System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Connected to DDME, preparing to send frames");
                        edge.processFrames(cameraIP,"127.0.0.1",socket,inputpathvideo);
                        socket.close();
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println(Color.PURPLE+Thread.currentThread().getName()+" closed");
                }
            }.start();
        }

    }
    public static void clean(String directoryName){
        File directory = new File(directoryName);
        File[] files = directory.listFiles();
        for (File file : files)
        {
            if (!file.delete()) { System.out.println("Failed to delete "+file); }
        }
    }

}
