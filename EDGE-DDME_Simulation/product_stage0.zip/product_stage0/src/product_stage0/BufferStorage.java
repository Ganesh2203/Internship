package product_stage0;

import java.util.concurrent.ConcurrentHashMap;

import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;

public class BufferStorage {
	public String storagePath ="";
	public int frameCounter = 0;
	public boolean cloningStarted = false;
	public int fetchCounter = 0;
	public ConcurrentHashMap<String, Integer> bufferMap;     //stores the frames and a integer index for mapping
	public int counter; 		   

	public BufferStorage(String path){
		bufferMap = new ConcurrentHashMap<String, Integer>();
		storagePath = path;
	}

	public void saveToBufferstorage(Mat img, int imgctr, String CameraIP) {
		//System.out.println("Saving to buffer storage");
		String fileName = storagePath + "\\" + imgctr + ".jpg";
		bufferMap.put(fileName,imgctr);
  	    Imgcodecs.imwrite(fileName , img);
  	    if(!cloningStarted){
  	    	fetchCounter=imgctr;
  	    	cloningStarted=true;
		}
  	    frameCounter++;
		//System.out.println("Saved to buffer storage");
  	}

	public Mat fetchFrame() {
		String fetchFrame = storagePath + "\\" + fetchCounter + ".jpg";
		System.out.println(Color.GREEN+Thread.currentThread().getName()+" : " +fetchFrame);

		Mat matrix = null;
		try{
		    matrix = Imgcodecs.imread(fetchFrame);
            counter = bufferMap.get(fetchFrame);

        }catch(Exception e){
            e.printStackTrace();
        }

//        if(!fetchFrame.isEmpty()){
//			counter = bufferMap.get(fetchFrame);
//		}else{
//			throw new Exception(){
//				@Override
//				public String getMessage() {
//					return "Frame is null";
//				}
//			};
//		}
		fetchCounter++;
		return matrix;
	}
	public int getCounter() {
		return counter;
	}

}
