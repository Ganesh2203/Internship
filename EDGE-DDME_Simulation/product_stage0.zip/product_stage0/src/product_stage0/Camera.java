package product_stage0;

import product_stage0.Edge;

public class Camera {
    private int fps;
    private String IP;      //IP address
    private Edge assocEdge;

    public Camera(int fps, Edge assocEdge, String IP) {
        this.setFps(fps);
        this.setAssocEdge(assocEdge);
        this.setIP(IP);
    }

    //getters and setters

    public int getFps() {
        return fps;
    }

    public void setFps(int fps) {
        this.fps = fps;
    }

    public Edge getAssocEdge() {
        return assocEdge;
    }

    public void setAssocEdge(Edge assocEdge) {
        this.assocEdge = assocEdge;
    }

	public String getIP() {
		return IP;
	}

	public void setIP(String iP) {
		this.IP = iP;
	}

}
