package product_stage0;
//@author Ganesh Sonwale

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;
public class Edge{
	private String IP;      //IP address
    public int cameraCap;  //number of cameras that can be associated to this edge (for now -> 1)
    public List<Camera> cameraList;    //lit of cameras associated
    public BufferStorage buffer;
    static int framectr = 0;
    public AtomicBoolean startClone;
    public AtomicBoolean canFetch;

    public Edge(String IP,  int cameraCap,BufferStorage Buffer,AtomicBoolean bufferClone,AtomicBoolean canFetch) {
    	this.setIP(IP);
        this.cameraCap = cameraCap;
        cameraList = new ArrayList<Camera>();
        buffer = Buffer;
        startClone = bufferClone;
        this.canFetch = canFetch;
    }

    public boolean addCamera(Camera cam){
        if (cameraList.size()>=this.cameraCap){
            return false;
        }
        cameraList.add(cam);
        return true;
    }
    private byte[] convertMattoBytes(Mat m){
        MatOfByte matOfByte = new MatOfByte();
        Imgcodecs.imencode(".jpg", m, matOfByte);
        //System.out.println("Length : "+byteArray.length);
        return matOfByte.toArray();
    }


    /*==============================================================================================================
	    										query  processing
	==============================================================================================================*/

    private String findScore(Mat test, String query_HOG){
        //String to be returned : score,x,y

        return HOG.compare(test,query_HOG);
    }

    private String processQuery(String query_HOG) throws Exception {
        Mat frame = buffer.fetchFrame();
        if(!frame.empty()){
            System.out.println(Color.GREEN+Thread.currentThread().getName()+" : frame fetched");
            String s = findScore(frame,query_HOG);
            System.out.println(Color.GREEN+Thread.currentThread().getName()+" : finding score : "+s);
            return s;
        }
        System.out.println(Color.GREEN+Thread.currentThread().getName()+" : frame fetched is empty");

        return "NULL";
    }

    //listen for the connection request from DDME CU for query
    public void listeningQuery(){
        try
        {
            int Edge_Port = 0;
            ServerSocket server = new ServerSocket(5001);
            System.out.println(Color.GREEN+Thread.currentThread().getName()+" : Query Channel Started ...");
            Socket socket = server.accept();
            System.out.println(Color.GREEN+Thread.currentThread().getName()+" : Connection Received for QP from DDME");
            // takes input from the DDME CU
            DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            DataOutputStream out    = new DataOutputStream(socket.getOutputStream());
            String line = "";
            line = in.readUTF();
            startClone.set(true);
            System.out.println(Color.GREEN+Thread.currentThread().getName()+" : Flag Value set : "+startClone.get());
            //sending the acknowledgement to DDME CU
            out.writeUTF("ACK");
            out.flush();
            System.out.println(Color.GREEN+Thread.currentThread().getName()+" : Ack sent to DDME for Query received");
            //now we have received the HOG values for the FRAME (string separated by comma)
            String hog = line;
            System.out.println(Color.GREEN+Thread.currentThread().getName()+" : Started processing query ..."+line);
            //Thread.sleep(200);
            while (true){
                if(canFetch.get()){
                    break;
                }
            }
            System.out.println(Color.GREEN+Thread.currentThread().getName()+" : other thread started buffering");
            Thread.sleep(200);
            while(true){
                String score_send="";
                try{
                    score_send = processQuery(hog);
                    if(!score_send.equals("NULL")){
                        String s = score_send+","+buffer.getCounter();
                        out.writeUTF(s);
                        System.out.println(Color.GREEN+Thread.currentThread().getName()+ " : Calculate and send score : "+s);

                    }else{
                        System.out.println(Color.GREEN+Thread.currentThread().getName()+" Score is NULL");
                        out.writeUTF("Over");
                        startClone.set(false);
                        break;
                    }
                }catch(Exception e){
                    e.getMessage();
                }
            }

            System.out.println(Color.GREEN+Thread.currentThread().getName()+ " : Closing connection for query Channel");
            socket.close();
            in.close();
        } catch(IOException | InterruptedException i) { System.out.println(i); }
    }


    /*==============================================================================================================
                                            frame processing
    ==============================================================================================================*/
    //receiving frames from camera and consequently sending to DDME and storing their copy to buffer storage
    public void processFrames(String cameraIP, String EdgeIP, Socket socket,String inputPath) throws IOException {
        /**
         * here should be code that will receive frames from camera continuously
         * act as a client
         * available after connection between camera and edge
         */
        VideoCapture cap = new VideoCapture();
        cap.open(inputPath);
        int frames_per_second = (int) cap.get(Videoio.CAP_PROP_FPS);
        Mat imgRecv = new Mat();

        if (cap.isOpened())
        {   //now send the meta information
            DataOutputStream output = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            try{
                String c = cameraIP+","+frames_per_second;
                output.writeUTF(EdgeIP);
                output.writeUTF(String.valueOf(cameraCap));
                output.writeUTF(c);
                output.writeUTF("meta");
                System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Meta Data sent to DDME about the Edge");
                //System.out.println(EdgeIP+" , "+cameraCap+" , "+c);
                output.flush();
                //meta information sent
            }catch(IOException e){
                e.printStackTrace();
            }
            int c = 200;
            System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Sending of Frames started");
            while(cap.read(imgRecv) && c-->0) //the last frame of the movie will be invalid. check for it !
            {
                System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : Flag Value read: "+startClone.get());
                Imgproc.resize(imgRecv, imgRecv, new Size(64, 128));
//                if(c<=190){
//                    System.out.println("SETTING TRUE ------------------------------");
//                    startClone.set(true);
//                }
                if (startClone.get()) {
                    System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : BUFFER SAVING FRAMES : "+framectr);
                    buffer.saveToBufferstorage(imgRecv,framectr,cameraIP);
                    if(!canFetch.get()){
                        canFetch.set(true);
                        System.out.println(Color.PURPLE+Thread.currentThread().getName()+" : can start fetch is true");
                    }
                }
                try {
                    output.writeUTF("Not Over");
                    byte[] sendBytes = convertMattoBytes(imgRecv);
                    output.writeInt(sendBytes.length);
                    output.flush();
                    output.write(sendBytes);
                    output.flush();
                    output.writeUTF(cameraIP);
                    output.flush();
                    output.writeInt(frames_per_second);
                    output.flush();
                    output.writeInt(framectr);
                    output.flush();
                    //System.out.println("Sending the data to DDME");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                framectr++ ;
            }
            output.writeUTF("Over");
            output.close();
            cap.release();
        }
    }

    //getters and setters
    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }


}
